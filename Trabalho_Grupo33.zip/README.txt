
GRUPO 33

INTEGRANTES:
Nome: FELIPPE ROCHA LÔBO DE ABREU -- Matricula: 201765185AC
Nome: KETLEEN ANNE FARIA -- Matricula: 201965066AC
Nome: LUCAS GOLDNER RIBEIRO -- Matricula: 201965074AC
Nome: NÉLIO ALVES GOUVEA NETO -- Matricula: 201935037

Comando para compilar trabalho:
g++ main.cpp Grafo/Grafo.cpp Grafo/No.cpp Grafo/Aresta.cpp -o execGrupo33

Comando para execução:
./execGrupo33 input.txt output.txt <Opc_Direc> <Opc_Peso_Aresta> <Opc_Peso_Nos>